


#include "Mdl_IP_main.h"
#include "Mdl_IP_prot.h"



#define Mdl_IP_Init(a) (P_JMP_TABLE)->Mdl_IP_Init(a)

#define Mdl_IP_PersonDetection(a,b,c) (P_JMP_TABLE)->Mdl_IP_PersonDetection(a,b,c)
#define Mdl_IP_PersonDetection_ParamChg(a,b) (P_JMP_TABLE)->Mdl_IP_PersonDetection_ParamChg(a,b)

#define Mdl_IP_MovingDetection(a,b,c,d,e) (P_JMP_TABLE)->Mdl_IP_MovingDetection(a,b,c,d,e)
#define Mdl_IP_MovingDetection_ParamChg(a,b) (P_JMP_TABLE)->Mdl_IP_MovingDetection_ParamChg(a,b)

#define Mdl_IP_ImgRevise(a,b) (P_JMP_TABLE)->Mdl_IP_ImgRevise(a,b)
#define Mdl_IP_ImgRevise_ParamChg(a,b) (P_JMP_TABLE)->Mdl_IP_ImgRevise_ParamChg(a,b)














